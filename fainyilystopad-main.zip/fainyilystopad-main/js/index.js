// import { generateElement } from "./generateElement.js";
// import { insertFooter } from "./insertFooter.js";


document.addEventListener('DOMContentLoaded', () => {
  insertFooter();
});
