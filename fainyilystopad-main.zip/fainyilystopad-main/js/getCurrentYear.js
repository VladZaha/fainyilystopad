export const getCurrentYear = () => {
  const currentYear = new Date().getFullYear();
  return currentYear;
}
